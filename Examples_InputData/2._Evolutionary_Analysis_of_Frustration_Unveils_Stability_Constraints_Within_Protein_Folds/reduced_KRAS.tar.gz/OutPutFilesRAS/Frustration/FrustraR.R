library(frustratometeR)
PdbsDir <- "/gpfs/scratch/bsc08/bsc08453/postdoc/frustration_analysis/lehner_paper/frustraevo_output/RAS/OutPutFilesRAS/Frustration/"
ResultsDir <- "/gpfs/scratch/bsc08/bsc08453/postdoc/frustration_analysis/lehner_paper/frustraevo_output/RAS/OutPutFilesRAS/Frustration/"
dir_frustration(PdbsDir = PdbsDir, Mode = "singleresidue", ResultsDir = ResultsDir)
