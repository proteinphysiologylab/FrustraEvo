library(frustratometeR)
PdbsDir <- '/home/maria/Documentos/EvoFrustra/FrustraEvo_alpha/Frustration/'
ResultsDir <-'/home/maria/Documentos/EvoFrustra/FrustraEvo_alpha/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'singleresidue', ResultsDir = ResultsDir)
