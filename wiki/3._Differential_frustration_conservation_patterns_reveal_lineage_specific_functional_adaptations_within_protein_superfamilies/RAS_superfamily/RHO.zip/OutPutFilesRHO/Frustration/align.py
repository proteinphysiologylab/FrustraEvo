lista=open('/home/maria/Documentos/Gonzalo/Nuevos-BCN/RAS/RenamedModels/list_pdbs.txt')
out=open('ras.pml','w')

for line in lista.readlines():
	line=line.rstrip('\n')
	out.write('load '+line+'.pdb\n')

lista.close()

lista=open('/home/maria/Documentos/Gonzalo/Nuevos-BCN/RAS/RenamedModels/list_pdbs.txt')

for line in lista.readlines():
	line=line.rstrip('\n')
	out.write('align '+line+', O00212\n')

lista.close()
