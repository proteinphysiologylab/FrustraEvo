library(frustratometeR)
PdbsDir <- '/home/maria/Documentos/EvoFrustra/FrustraEvo_Both-Globin/Frustration/'
ResultsDir <- '/home/maria/Documentos/EvoFrustra/FrustraEvo_Both-Globin/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
