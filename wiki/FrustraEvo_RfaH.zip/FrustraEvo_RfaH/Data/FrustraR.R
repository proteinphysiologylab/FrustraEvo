library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_RfaH/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_RfaH/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
