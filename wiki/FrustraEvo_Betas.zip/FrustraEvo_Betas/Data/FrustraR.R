library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_Betas/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_Betas/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
