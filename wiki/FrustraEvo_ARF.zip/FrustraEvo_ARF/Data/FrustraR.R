library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_ARF/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_ARF/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
