library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_RAB/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_RAB/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
