library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_PlPro/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_PlPro/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
