library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_RAS/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_RAS/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
