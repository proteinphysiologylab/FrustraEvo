library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_C3/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_C3/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
