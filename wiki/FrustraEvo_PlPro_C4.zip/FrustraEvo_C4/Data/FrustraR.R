library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_C4/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_C4/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
