library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_RHO/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_RHO/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
