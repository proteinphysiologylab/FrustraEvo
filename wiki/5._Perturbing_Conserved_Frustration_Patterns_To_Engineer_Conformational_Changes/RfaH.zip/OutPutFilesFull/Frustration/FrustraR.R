library(frustratometeR)
OrderList <- c("rfah-full-yersiniapestis.pdb")
Pdb_sr <- dir_frustration(PdbsDir = "/home/maria/Documentos/AutoLogo/OutPutFilesFull/Frustration/", OrderList = OrderList, Mode = "singleresidue", ResultsDir = "/home/maria/Documentos/AutoLogo/OutPutFilesFull/Frustration/")