library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_Alfas/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_Alfas/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
