library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_20238231901214621/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_20238231901214621/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir,Graphics = FALSE)
