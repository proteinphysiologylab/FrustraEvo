library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_2023824115653918886/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_2023824115653918886/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir,Graphics = FALSE)
