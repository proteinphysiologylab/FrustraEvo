library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_2022122114524431133/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_2022122114524431133/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir)
