library(frustratometeR)
PdbsDir <- "/home/maria/Documentos/AutoLogo/OutPutFilesC1_NSP5/Frustration/"
ResultsDir <- "/home/maria/Documentos/AutoLogo/OutPutFilesC1_NSP5/Frustration/"
dir_frustration(PdbsDir = PdbsDir, Mode = "singleresidue", ResultsDir = ResultsDir)