library(frustratometeR)
PdbsDir <- "/home/maria/Documentos/AutoLogo/OutPutFilesNSP5_C4/Frustration/"
ResultsDir <- "/home/maria/Documentos/AutoLogo/OutPutFilesNSP5_C4/Frustration/"
dir_frustration(PdbsDir = PdbsDir, Mode = "singleresidue", ResultsDir = ResultsDir)