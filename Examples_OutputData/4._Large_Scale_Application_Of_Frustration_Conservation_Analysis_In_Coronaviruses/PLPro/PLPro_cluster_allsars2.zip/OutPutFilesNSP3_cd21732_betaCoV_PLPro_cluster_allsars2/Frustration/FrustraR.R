library(frustratometeR)
PdbsDir <- "/home/maria/Documentos/EvoFrustra/OutPutFilesPlpro/Frustration/"
ResultsDir <- "/home/maria/Documentos/EvoFrustra/OutPutFilesPlpro/Frustration/"
dir_frustration(PdbsDir = PdbsDir, Mode = "singleresidue", ResultsDir = ResultsDir)
